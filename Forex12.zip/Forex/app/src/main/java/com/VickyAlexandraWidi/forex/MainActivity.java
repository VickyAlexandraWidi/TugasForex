package com.VickyAlexandraWidi.forex;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.provider.Telephony;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import java.text.DecimalFormat;
import java.util.FormatFlagsConversionMismatchException;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {
    private ProgressBar loadingProgressBar;
    private SwipeRefreshLayout swipeRefreshLayout1;
    private TextView audTextView, bndTextView, hkdTextView, idrTextView, xauTextView, rubTextView, sgdTextView, usdTextView, jpyTextView, krwTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipeRefreshLayout1 = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout1);
        audTextView = (TextView) findViewById(R.id.audTextView);
        bndTextView = (TextView) findViewById(R.id.bndTextView);
        hkdTextView = (TextView) findViewById(R.id.hkdTextView);
        idrTextView = (TextView) findViewById(R.id.idrTextView);
        xauTextView = (TextView) findViewById(R.id.xauTextView);
        rubTextView = (TextView) findViewById(R.id.rubTextView);
        sgdTextView = (TextView) findViewById(R.id.sgdTextView);
        usdTextView = (TextView) findViewById(R.id.usdTextView);
        jpyTextView = (TextView) findViewById(R.id.jpyTextView);
        krwTextView = (TextView) findViewById(R.id.krwTextView);
        loadingProgressBar = (ProgressBar) findViewById(R.id.loadingProgressBar);

        initSwipeRefreshLayout();
        initForex();
    }

    private void initForex() {
        loadingProgressBar.setVisibility(TextView.VISIBLE);

        String url = "https://openexchangerates.org/api/latest.json?app_id=4d190bf8d42b4a9eb2b51ab699227af0";

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                //Log.d("*tw*", new String(responseBody));
                Gson gson = new Gson();
                RootModel rootModel =gson.fromJson(new String(responseBody),RootModel.class);
                RatesModel ratesModel = rootModel.getRatesModel();

                double aud = ratesModel.getIDR() / ratesModel.getAUD();
                double bnd = ratesModel.getIDR() / ratesModel.getBND();
                double hkd = ratesModel.getIDR() / ratesModel.getHKD();
                double xau = ratesModel.getIDR() / ratesModel.getXAU();
                double rub = ratesModel.getIDR() / ratesModel.getRUB();
                double sgd = ratesModel.getIDR() / ratesModel.getSGD();
                double usd = ratesModel.getIDR() / ratesModel.getUSD();
                double jpy = ratesModel.getIDR() / ratesModel.getJPY();
                double krw = ratesModel.getIDR() / ratesModel.getKRW();
                double idr = ratesModel.getIDR();

                audTextView.setText(formatNumber(aud, ###,##0.##));
                bndTextView.setText(formatNumber(bnd, ###,##0.##));
                hkdTextView.setText(formatNumber(hkd, ###,##0.##));
                xauTextView.setText(formatNumber(xau, ###,##0.##));
                rubTextView.setText(formatNumber(rub, ###,##0.##));
                sgdTextView.setText(formatNumber(sgd, ###,##0.##));
                usdTextView.setText(formatNumber(usd, ###,##0.##));
                jpyTextView.setText(formatNumber(jpy, ###,##0.##));
                krwTextView.setText(formatNumber(krw, ###,##0.##));
                idrTextView.setText(formatNumber(idr, ###,##0.##));

                loadingProgressBar.setVisibility(TextView.INVISIBLE);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        })
    }

    private void initSwipeRefreshLayout() {
        swipeRefreshLayout1.setOnRefreshListener(() {
            initForex();
        });
    }

    public String formatNumber(double number, String format) {
        DecimalFormat decimalFormat = new DecimalFormat(format);
        return decimalFormat.format(number);
    }
    }